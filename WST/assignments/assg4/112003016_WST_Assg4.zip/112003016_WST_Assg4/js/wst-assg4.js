

function clearform() {
 
    // $('#mode').val('reset');
    // document.forms["contact-form"].submit();

    window.location.href = '/index.php';
}
